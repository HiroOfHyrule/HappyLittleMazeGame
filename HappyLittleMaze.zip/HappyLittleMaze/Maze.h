#pragma once

#include <curses.h>
#include <array>
#include <string>

class Maze
{
public:
	Maze(WINDOW* window);
	~Maze();

	void draw();

	bool isComplete();
	void clearLevel();
	void loadLevel(std::string levelString);

	bool moveLeft();
	bool moveRight();
	bool moveUp();
	bool moveDown();

private:
	static constexpr int xLength = 20;
	static constexpr int yLength = 8;

	std::array<std::array<int, xLength>, yLength> map;
	int playerX, playerY;
	int endX, endY;

	void completionCheck();
	WINDOW* window;
};

class MazeFinishedException : private std::exception
{
	virtual const char* what() const noexcept { return "Done."; };
};