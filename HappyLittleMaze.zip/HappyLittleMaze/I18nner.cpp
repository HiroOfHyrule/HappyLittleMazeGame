#include "I18nner.h"

#include <fstream>
#include <string>
#include <string.h>

I18nner::I18nner()
{
}

I18nner::~I18nner()
{
}

std::string I18nner::get(std::string key)
{
  auto val = map.find(key);
  if(val != map.end())
    return val->second;
  else
    return key;
}

bool I18nner::getI18n(std::string path)
{
  std::fstream file(path);
  if (!file.is_open())
    return false;

    char buffer[1024];

    std::string currentKey;
    std::string currentValue;

    do
    {
      file.getline(buffer,1024);
      currentKey = std::string(buffer, strlen(buffer));
    } while (currentKey[0] != '$' && !file.eof());

    while(!file.eof())
    {
      file.getline(buffer,1024);

      if(file.eof())
      {
        map[currentKey] = currentValue;
      }
      else if (buffer[0] == '$')
      {
        map[currentKey] = currentValue;
        currentKey = std::string(buffer, strlen(buffer));
        currentValue.clear();
      }
      else if(buffer[0] != '%')
      {
        currentValue.append(std::string(buffer, strlen(buffer)));
        currentValue += '\n';
      }


    }

    return true;
}
