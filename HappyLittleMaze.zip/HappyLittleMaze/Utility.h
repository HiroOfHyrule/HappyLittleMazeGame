#pragma once
#include "Maze.h"
#include "I18nner.h"

#include <string>
#include <sol/sol.hpp>

void mazeOutput(std::string output);
void setupLuaState(sol::state& lua, Maze& maze, I18nner& I18n);
void doScript(sol::state& lua, std::string script);
