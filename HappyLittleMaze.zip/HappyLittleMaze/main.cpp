#include <curses.h>

#include "Utility.h"
#include "Maze.h"
#include "I18nner.h"

int main()
{
	sol::state lua;

	WINDOW* window = initscr();

	I18nner I18n;
	I18n.getI18n("English.txt");

	Maze maze(window);
	maze.loadLevel(I18n.get("$Level1").c_str());

	setupLuaState(lua,maze, I18n);

	char inputBuffer[255];
	inputBuffer[0] = ' '; inputBuffer[1] = '\0';

	while (inputBuffer[0] != '\0')
	{
		move(0, 0);
		addstr(I18n.get("$Intro").c_str());
		refresh();

		getnstr(inputBuffer, 255);
		std::string ss = inputBuffer;

		doScript(lua,ss);
		clear();
	}

	clear();
	maze.draw();

	move(16,0);
	mazeOutput(I18n.get("$Level1Desciption"));


	move(getmaxy(window)-1,0);
	refresh();

	while (!maze.isComplete())
	{
		getnstr(inputBuffer, 255);
		std::string ss = inputBuffer;

		doScript(lua,ss);

		maze.draw();
		refresh();
	}


	refresh();
	while (true);

	return 0;
}
