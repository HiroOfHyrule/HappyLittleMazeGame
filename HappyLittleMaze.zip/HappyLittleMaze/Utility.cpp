#include "Utility.h"

#include <curses.h>


void mazeOutput(std::string output)
{
	move(16, 0);
	addstr(output.c_str());
}

void changeLanguage(sol::state& lua, Maze& maze, I18nner& I18n, std::string filepath)
{
	I18n.getI18n(filepath);

	setupLuaState(lua,maze,I18n);
}

std::string sanitize(std::string s)
{
	std::string output = s;
	output.erase(
		std::remove_if(output.begin(),output.end(),
		[](const char c){return c == '\n';})
	);
	return output;
}

void setupLuaState(sol::state& lua, Maze& maze, I18nner& I18n)
{
	lua[sanitize(I18n.get("$moveLeft"))] = [&maze](){maze.moveLeft();};
	lua[sanitize(I18n.get("$moveRight"))] = [&maze](){maze.moveRight();};
	lua[sanitize(I18n.get("$moveUp"))] = [&maze](){maze.moveUp();};
	lua[sanitize(I18n.get("$moveDown"))] = [&maze](){maze.moveDown();};
	lua[sanitize(I18n.get("$changeLanguage"))] = [&I18n,&lua,&maze](std::string filepath)
		{changeLanguage(lua,maze,I18n,filepath);};
}

void doScript(sol::state& lua, std::string script)
{
	try
	{
		lua.script(script);
	}
	catch (std::exception& e)
	{
		clear();
		move(16,0);
		addstr(e.what());
	}
}
