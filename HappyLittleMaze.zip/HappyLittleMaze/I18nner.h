#pragma once
#include <string>
#include <unordered_map>

#include <curses.h>

class I18nner
{
public:
  I18nner();
  ~I18nner();

  std::string get(std::string key);
  bool getI18n(std::string path);

private:
  std::unordered_map<std::string,std::string> map;
};
